package org.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.fms.dao.FilmDaoImplForList;
import com.flp.fms.domain.Film;

/**
 * Servlet implementation class GetAllFilms
 */
public class GetAllFilms extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		FilmDaoImplForList filmDaoImpl=new FilmDaoImplForList();
		List<Film> films=new ArrayList<>();
		films=filmDaoImpl.getAllFilms();
		
		PrintWriter out=response.getWriter();
		out.println("<html>"
				+ "<head>GetAllFilms</head>"
				+ "<body>"
				+ "<table border='1'>"
				
				+ "<tr>"
				+ "<th>FilmId</th>"
				+ "<th>Title</th>"
				+ "<th>Description</th>"
				+ "<th>Release Year</th>"
				+ "<th>Original Language</th>"
				+ "<th>Rental Duration</th>"
				+ "<th>Length</th>"
				+ "<th>Replacement Cost</th>"
				+ "<th>Rating</th>"
				+ "<th>Special Features</th>"
				+ "<th>Category</th>"
				+ "</tr>");
				
	
				for(Film allFilms:films){
					
					out.println(
							
					"<tr>"
					+"<td>"+allFilms.getFilm_ID()+"</td>"
					+"<td>"+allFilms.getTitle()+"</td>"
					+"<td>"+allFilms.getDescription()+"</td>"
					+"<td>"+allFilms.getReleaseYear()+"</td>"
					+"<td>"+allFilms.getOriginalLanguage()+"</td>"
					+"<td>"+allFilms.getRentalDuration()+"</td>"
					+"<td>"+allFilms.getLength()+"</td>"
					+"<td>"+allFilms.getReplacementCost()+"</td>"
					+"<td>"+allFilms.getRatings()+"</td>"
					+"<td>"+allFilms.getSpecialFeatures()+"</td>"
					+"<td>"+allFilms.getCategory()
					+"</td>"
					+ "</tr>");
				}
				
				out.println(		
				"</table>"
				+ "</body>"
				+ "</html>");
		
		
	}

}
